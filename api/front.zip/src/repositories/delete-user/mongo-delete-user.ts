import { ObjectId } from 'mongodb';
import { IDeleteUserRepository } from '../../controllers/delete-user/protocols';
import { MongoClient } from '../../database/mongo';
import { User } from '../../models/user';

export class MongoDeleteUserRepository implements IDeleteUserRepository {
    async deleteUser(id: string): Promise<User> {
        const user = await MongoClient.db.collection<Omit<User, 'id'>>('users').findOne({ _id: new ObjectId(id) });
        if (!user) {
            throw new Error('Usuário não encontrado');
        }
        const { deletedCount } = await MongoClient.db.collection('users').deleteOne({ _id: new ObjectId(id) });
        if (!deletedCount) {
            throw new Error('Usuário não deletado');
        }
        // separo o _id do resto do usuário
        const { _id, ...rest } = user;

        // renomeia o _id para id
        return { id: _id.toHexString(), ...rest };
    }
}
